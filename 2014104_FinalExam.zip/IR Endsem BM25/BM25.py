print("Importing Libraries. Please Wait...")

import scipy.sparse as sp 
import re
from normalization import normalize_corpus
from nltk.corpus import stopwords
from utils import build_feature_matrix
import numpy as np


flatten = lambda l: [item for sublist in l for item in sublist]

stop = set(stopwords.words('english'))
documents_list = list()


print("Loading Documents.Please Wait...")


i = 1
temp_list = list()
temp_list_11 = list()
        
filename = "corpus.txt"
f = open(filename,"r");
#print("I : ",str(i));
lines = f.readlines();
for j in lines:

    if "#" in j and i>1:
        #print(i)

        temp_list_11 = [lm.replace('\n','') for lm in temp_list_11]
        temp_list = list()
        temp_list = ' '.join(temp_list_11)  #No Stemming Required

        documents_list.append(temp_list)
        i= i+1
        
        temp_list_11 = list()


    elif "#" in j:
        i= i+1
        #print(i , "  ",j)
        
    else:
        temp_list_11.append(j)

temp_list_11 = [lm.replace('\n','') for lm in temp_list_11]
temp_list = list()
temp_list = ' '.join(temp_list_11)        #No Stemming Required
documents_list.append(temp_list)
i= i+1

del temp_list
del temp_list_11

print("Read Documents list size : ",len(documents_list))
datum_corpus = documents_list
print("Computing Results. Please Wait...")


query_docs = ['Portable operating system', 'Parallel algorithm',
            'Applied stochastic process','Perform evaluation and model of computer system',
            'Parallel process in information retrieval']  


norm_corpus = normalize_corpus(datum_corpus, lemmatize=False)
tfidf_vectorizer, tfidf_features = build_feature_matrix(norm_corpus,
                                                        feature_type='tfidf',
                                                        ngram_range=(1, 1), 
                                                        min_df=0.0, max_df=1.0)
                                                        
norm_query_docs =  normalize_corpus(query_docs, lemmatize=True)            
query_docs_tfidf = tfidf_vectorizer.transform(norm_query_docs)


def compute_corpus_term_idfs(corpus_features, norm_corpus):
    
    dfs = np.diff(sp.csc_matrix(corpus_features, copy=True).indptr)
    dfs = 1 + dfs 
    total_docs = 1 + len(norm_corpus)
    idfs = 1.0 + np.log(float(total_docs) / dfs)
    return idfs


def compute_bm25_similarity(doc_features, corpus_features,
                            corpus_doc_lengths, avg_doc_length,
                            term_idfs, k1=1.5, b=0.75, top_n=3):
    corpus_features = corpus_features.toarray()
    doc_features = doc_features.toarray()[0]
    doc_features[doc_features >= 1] = 1
    
    doc_idfs = doc_features * term_idfs
    numerator_coeff = corpus_features * (k1 + 1)
    numerator = np.multiply(doc_idfs, numerator_coeff)
    denominator_coeff =  k1 * (1 - b + 
                                (b * (corpus_doc_lengths / 
                                        avg_doc_length)))
    denominator_coeff = np.vstack(denominator_coeff)
    denominator = corpus_features + denominator_coeff
    bm25_scores = np.sum(np.divide(numerator,
                                   denominator),
                         axis=1)

    top_docs = bm25_scores.argsort()[::-1][:top_n]
    top_docs_with_score = [(index, round(bm25_scores[index], 3))
                            for index in top_docs]
    return top_docs_with_score

vectorizer, corpus_features = build_feature_matrix(norm_corpus,
                                                   feature_type='frequency')
query_docs_features = vectorizer.transform(norm_query_docs)

doc_lengths = [len(doc.split()) for doc in norm_corpus]   
avg_dl = np.average(doc_lengths) 
corpus_term_idfs = compute_corpus_term_idfs(corpus_features,
                                            norm_corpus)
                 
print ('BM25 Results :')
print ('='*60)
for index, doc in enumerate(query_docs):
    
    doc_features = query_docs_features[index]
    top_similar_docs = compute_bm25_similarity(doc_features,
                                               corpus_features,
                                               doc_lengths,
                                               avg_dl,
                                               corpus_term_idfs,
                                               k1=1, b=0.5,
                                               top_n=10)
    print ('Query ',index+1 ,':', doc)
    print ('Top', len(top_similar_docs), 'similar docs:')
    #print ('-'*40)
    rank = 1
    for doc_index, sim_score in top_similar_docs:
        print ('Rank : {} : Doc : {} : BM25 Score: {}'.format(rank, doc_index+1,
                                                                 sim_score)) 
        rank+=1
    print ('='*60)
    print ('='*60)
    print
