

print("Importing Libraries.Please Wait...")

    
import re
import nltk
import sklearn
import nltk
import enchant
from nltk.stem.porter import *
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from scipy.sparse import csr_matrix, find
from enchant.checker import SpellChecker

nltk.download("stopwords")    
d = enchant.request_dict("en_US")
chkr = SpellChecker("en_US")
stop = set(stopwords.words('english'))


flatten = lambda l: [item for sublist in l for item in sublist]



word_set = set()
documents_list = list()
train_set = list()
dictionaries={}
print("Loading Documents.Please Wait...")
for i in range(1,100):
    document = list()
    filename = "./IR_Data/document"+str(i)+".txt"
    f = open(filename,"r");
    #print("I : ",str(i));
    lines = f.readlines();
    for j in lines:
        #print len(lines)
        #print j
                
        document.append(j)


    stemmer = PorterStemmer()


    temp_list = list()
    for line in document:
        temp_list.append(re.sub("[^\w]", " ",  line).split())  #Remove Special Characters
  #  print("\n\n\n\nAfter Special Character Removal:\n\n\n\n")

    temp_list = flatten(temp_list)

    document = temp_list
    document = [x.lower() for x in document]
    document = [word for word in document if word not in stop]   #Remove Stop Words
    
 #   print("\n\n\n\nAfter Stopword Removal:\n\n\n\n")


    #print(document)
    
    temp_list = document
    
    document = [stemmer.stem(word) for word in temp_list]
#    print("\n\n\n\nAfter Stemming:\n\n\n\n")
    #print(document)
    train_set.append(' '.join(document))
    documents_list.append(document)
    word_set = set(word_set).union(set(document))
        


for x in range (1,100):
    doc = 'doc%d' % x 
    dictionaries[doc] = {}
    dictionaries[doc] = dict.fromkeys(word_set,0) 


for x in range (1,100):
    doc = 'doc%d' % x 
    #print("X = ",x)
    for word in documents_list[x-1]:
        dictionaries[doc][word] += 1

    

vectorizer = TfidfVectorizer(vocabulary=word_set)
matrix = vectorizer.fit_transform(train_set)

#print("Hola3")
#print(type(matrix.toarray()))
matrix2 = matrix.toarray()
#print("2a",matrix2[0][0])
#print("2b",matrix2[1][1])
#print("SHAPE :",matrix2.shape)

#print(matrix.toarray())
#print("Hola4")


#print("Dimen1 : ",matrix2.shape[0])
#print("Dimen2 : ",matrix2.shape[1])






while True:         # Loop continuously
    print("\nEnter Search Query :")
    inp = input()   # Get the input
    chkr.set_text(inp)

    inp = inp.lower()
    
    
    #inp = stemmer.stem(inp)
    test_set=list()
    test_set.append(inp)
    #print("Modified Input : ",inp)

    temp_list = list()
    temp_list.append(re.sub("[^\w]", " ",  inp).split())  #Remove Special Characters
    #print(temp_list)
    if inp == "exit0":       # Terminate
        break
    else:

        temp_list = flatten(temp_list)

        temp_list2 = list()
        for i in range(0,len(temp_list)):
            
            if(temp_list[i] not in stop):
                
                temp_list2.append(stemmer.stem(temp_list[i]))
        temp_list = [word for word in temp_list if word not in stop]   #Remove Stop Words
        
        to_break = 0;
        if(len(temp_list2)==0):
            print("Please refine search query to include more non-stopword terms!!!\n")
            
        else:    
            
            if(to_break == 0):
                output_dict = dict()
                for j in range(0,len(temp_list2)):
                    search_val = vectorizer.vocabulary_.get(temp_list2[j])
                   # print("temp_list[j] : ",temp_list[j])
                   # print("Search_val : ",search_val)
                    if(search_val is None):
                        continue
                            
                    for k in range(0, matrix2.shape[0]):
                        if(matrix2[k][search_val]>0):
                            if((k+1) in output_dict):
                                #print("\nAlready dict term exists\n")
                                output_dict[k+1] +=  matrix2[k][search_val]
                            else:
                                #print("\nNew dict term entry\n")
                                output_dict[k+1] =  matrix2[k][search_val]
                            to_break = 1

                #print("Non Sorted Dict : \n\n\n",output_dict)        
                   
                
            for i in range(0,len(documents_list)):
                #print("i: ",i," Set : tpl2 :",set(temp_list2))
                #print("i: ",i," Set : doc :",set(documents_list[i]))
                if(set(temp_list2) < set(documents_list[i])):
                    if((i+1) in output_dict):
                        output_dict[i+1]+=0.25
                    else:
                        output_dict[i+1] = 0.10
#            print("Non Sorted Dict : \n\n\n",output_dict)        
#            print("Sorted Dict : \n")  
#            print(sorted_dict)
            a_keys = sorted(output_dict, key=output_dict.get, reverse=True)

            doc_counter = 1
            for r in a_keys:
                print("Rank : ",doc_counter,"Score : ",output_dict[r],'\nDocument Name : document{}.txt\n'.format(r))
                doc_counter+=1
            
            if(len(output_dict) == 0):
                print("No Documents Found.")
                err_counter1 = 0
                i = 1
                flag_break = 0
                for err in chkr:
                    if(flag_break == 0):
                        print(" The following words may be misspelled :")
                        flag_break = 1
                    print(i," : ", err.word)
                    print("Possible Corrections : ", d.suggest(err.word))
                    i+=1
                    err_counter1 += 1
                
                            
            else:
                err_counter2 = 0
                for err in chkr:
                    err_counter2 += 1

                if(err_counter2>0):
                    print("The above documents matched your query; however, the following words may be misspelled :")
                    i = 1
                    for err in chkr:
                        print(i," : ", err.word)
                        print("Possible Corrections : ", d.suggest(err.word))
                        i+=1
