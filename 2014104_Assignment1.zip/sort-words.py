import random
import timeit

random.seed('slaqwetibartfastgodapple')

f = open("names.txt")

total_list = list()

for line in f:
    line = line.split()
    total_list = total_list + line

new_list = list()
    
for i in range (0,1000):
    new_list.append(random.choice(total_list))

#print new_list    

new_list = [x.lower() for x in new_list]


import timeit
start_time = timeit.default_timer()

new_list.sort()

#print new_list    

print (timeit.default_timer() - start_time)
